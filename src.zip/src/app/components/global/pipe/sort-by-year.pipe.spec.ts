import { SortByYearPipe } from './sort-by-year.pipe';

describe('SortByYearPipe', () => {
  it('create an instance', () => {
    const pipe = new SortByYearPipe();
    expect(pipe).toBeTruthy();
  });
});
